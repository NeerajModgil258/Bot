const Discord = require('discord.js')
module.exports = {
name: "free-nitro",
category: "Fun",
description: "Free-Nitro Prank!",
execute: async (client, message, args) => {
    message.channel.send('https://cdn.discordapp.com/attachments/751829074095112192/759432294279675924/1601133141174.png')
}
}